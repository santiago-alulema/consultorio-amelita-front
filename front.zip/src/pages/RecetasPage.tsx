import {
    ActionIcon,
    Button,
    Group,
    Modal,
    NumberInput,
    Select,
    SimpleGrid,
    Table,
    Textarea,
    TextInput,
    Title,
} from '@mantine/core';
import { useDisclosure } from '@mantine/hooks';
import { IconPlus, IconTrash } from '@tabler/icons-react';
import { useEffect, useState } from 'react';
import { useSearchParams } from 'react-router-dom';
import { api } from '../api/api';

const nuevoDetalle = () => ({
    productoId: null,
    medicamento: '',
    presentacion: '',
    dosis: '',
    frecuencia: '',
    duracion: '',
    cantidad: 1,
    indicaciones: '',
});

const recetaVacia = () => ({
    pacienteId: '',
    consultaId: null,
    indicacionesGenerales: '',
    detalles: [nuevoDetalle()],
});

export default function RecetasPage() {
    const [searchParams, setSearchParams] = useSearchParams();
    const [data, setData] = useState<any[]>([]);
    const [pacientes, setPacientes] = useState<any[]>([]);
    const [productos, setProductos] = useState<any[]>([]);
    const [form, setForm] = useState<any>(recetaVacia());
    const [opened, { open, close }] = useDisclosure();

    const load = async () => {
        const response = await api.get('/recetas');
        setData(response.data);
    };

    useEffect(() => {
        Promise.all([api.get('/recetas'), api.get('/pacientes'), api.get('/productos')]).then(
            ([recetasResponse, pacientesResponse, productosResponse]) => {
                setData(recetasResponse.data);
                setPacientes(pacientesResponse.data);
                setProductos(productosResponse.data);
            },
        );
    }, []);

    useEffect(() => {
        if (searchParams.get('nueva') !== '1') {
            return;
        }

        setForm({
            ...recetaVacia(),
            pacienteId: searchParams.get('pacienteId') ?? '',
            consultaId: searchParams.get('consultaId'),
        });
        open();
    }, [searchParams]);

    function abrirNuevaReceta() {
        setForm(recetaVacia());
        open();
    }

    function cerrarModal() {
        close();

        if (searchParams.get('nueva')) {
            setSearchParams({}, { replace: true });
        }
    }

    function actualizarDetalle(index: number, campo: string, value: any) {
        const detalles = [...form.detalles];
        detalles[index] = { ...detalles[index], [campo]: value };

        if (campo === 'productoId') {
            const producto = productos.find((item) => item.id === Number(value));

            if (producto) {
                detalles[index].medicamento = producto.nombre;
                detalles[index].presentacion = [
                    producto.concentracion,
                    producto.presentacion,
                ]
                    .filter(Boolean)
                    .join(' ');
            }
        }

        setForm({ ...form, detalles });
    }

    function eliminarDetalle(index: number) {
        if (form.detalles.length === 1) {
            return;
        }

        setForm({
            ...form,
            detalles: form.detalles.filter((_: any, itemIndex: number) => itemIndex !== index),
        });
    }

    async function guardarReceta() {
        await api.post('/recetas', {
            ...form,
            pacienteId: Number(form.pacienteId),
            consultaId: form.consultaId ? Number(form.consultaId) : null,
            detalles: form.detalles.map((detalle: any) => ({
                ...detalle,
                productoId: detalle.productoId ? Number(detalle.productoId) : null,
            })),
        });

        cerrarModal();
        setForm(recetaVacia());
        await load();
    }

    return (
        <>
            <Group justify="space-between" mb="md">
                <Title order={2}>Recetas</Title>
                <Button onClick={abrirNuevaReceta}>Nueva receta</Button>
            </Group>

            <Table striped withTableBorder highlightOnHover>
                <Table.Thead>
                    <Table.Tr>
                        <Table.Th>Fecha</Table.Th>
                        <Table.Th>Paciente</Table.Th>
                        <Table.Th>Médico</Table.Th>
                        <Table.Th>Medicamentos</Table.Th>
                    </Table.Tr>
                </Table.Thead>

                <Table.Tbody>
                    {data.map((receta) => (
                        <Table.Tr key={receta.id}>
                            <Table.Td>
                                {new Date(receta.fechaEmision).toLocaleString()}
                            </Table.Td>
                            <Table.Td>{receta.paciente}</Table.Td>
                            <Table.Td>{receta.medico}</Table.Td>
                            <Table.Td>
                                {receta.detalles
                                    .map((detalle: any) => detalle.medicamento)
                                    .join(', ')}
                            </Table.Td>
                        </Table.Tr>
                    ))}
                </Table.Tbody>
            </Table>

            <Modal
                opened={opened}
                onClose={cerrarModal}
                title="Emitir receta"
                size="xl"
            >
                <Select
                    searchable
                    label="Paciente"
                    data={pacientes.map((paciente) => ({
                        value: String(paciente.id),
                        label: `${paciente.identificacion} - ${paciente.nombres} ${paciente.apellidos}`,
                    }))}
                    value={form.pacienteId}
                    onChange={(value) => setForm({ ...form, pacienteId: value ?? '' })}
                />

                <Textarea
                    mt="sm"
                    label="Indicaciones generales"
                    value={form.indicacionesGenerales}
                    onChange={(event) =>
                        setForm({
                            ...form,
                            indicacionesGenerales: event.currentTarget.value,
                        })
                    }
                />

                {form.detalles.map((detalle: any, index: number) => (
                    <SimpleGrid
                        key={index}
                        cols={{ base: 1, sm: 4 }}
                        mt="md"
                        p="md"
                        style={{ border: '1px solid var(--mantine-color-gray-3)', borderRadius: 8 }}
                    >
                        <Select
                            searchable
                            clearable
                            label="Producto"
                            data={productos.map((producto) => ({
                                value: String(producto.id),
                                label: producto.nombre,
                            }))}
                            value={
                                detalle.productoId ? String(detalle.productoId) : null
                            }
                            onChange={(value) =>
                                actualizarDetalle(index, 'productoId', value)
                            }
                        />

                        <TextInput
                            label="Medicamento"
                            value={detalle.medicamento}
                            onChange={(event) =>
                                actualizarDetalle(
                                    index,
                                    'medicamento',
                                    event.currentTarget.value,
                                )
                            }
                        />

                        <TextInput
                            label="Presentación"
                            value={detalle.presentacion}
                            onChange={(event) =>
                                actualizarDetalle(
                                    index,
                                    'presentacion',
                                    event.currentTarget.value,
                                )
                            }
                        />

                        <TextInput
                            label="Dosis"
                            value={detalle.dosis}
                            onChange={(event) =>
                                actualizarDetalle(index, 'dosis', event.currentTarget.value)
                            }
                        />

                        <TextInput
                            label="Frecuencia"
                            value={detalle.frecuencia}
                            onChange={(event) =>
                                actualizarDetalle(
                                    index,
                                    'frecuencia',
                                    event.currentTarget.value,
                                )
                            }
                        />

                        <TextInput
                            label="Duración"
                            value={detalle.duracion}
                            onChange={(event) =>
                                actualizarDetalle(index, 'duracion', event.currentTarget.value)
                            }
                        />

                        <NumberInput
                            label="Cantidad"
                            min={0}
                            value={detalle.cantidad}
                            onChange={(value) =>
                                actualizarDetalle(index, 'cantidad', value)
                            }
                        />

                        <TextInput
                            label="Indicaciones"
                            value={detalle.indicaciones}
                            onChange={(event) =>
                                actualizarDetalle(
                                    index,
                                    'indicaciones',
                                    event.currentTarget.value,
                                )
                            }
                        />

                        <Group align="flex-end">
                            <ActionIcon
                                color="red"
                                variant="light"
                                disabled={form.detalles.length === 1}
                                onClick={() => eliminarDetalle(index)}
                            >
                                <IconTrash size={16} />
                            </ActionIcon>
                        </Group>
                    </SimpleGrid>
                ))}

                <Button
                    variant="light"
                    mt="md"
                    leftSection={<IconPlus size={16} />}
                    onClick={() =>
                        setForm({
                            ...form,
                            detalles: [...form.detalles, nuevoDetalle()],
                        })
                    }
                >
                    Agregar medicamento
                </Button>

                <Group justify="flex-end" mt="md">
                    <Button variant="default" onClick={cerrarModal}>
                        Cancelar
                    </Button>
                    <Button onClick={guardarReceta} disabled={!form.pacienteId}>
                        Guardar receta
                    </Button>
                </Group>
            </Modal>
        </>
    );
}
