# Clínica Amelita - Frontend

React + Vite + TypeScript + Mantine.

## Módulos incluidos
- Login y menú por permisos.
- Dashboard.
- Pacientes.
- Historia clínica.
- Consultas.
- Recetas e histórico.
- Productos e importación Excel.
- Inventario y ajustes.
- Ventas.
- Pedidos.
- Carga XML/RIDE SRI.
- Reportes diarios.
- Usuarios y roles.

## Ejecutar
```bash
npm install
npm run dev
```
Copiar `.env.example` a `.env` y ajustar `VITE_API_URL`.
